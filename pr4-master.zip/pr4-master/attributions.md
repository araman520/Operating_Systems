# References and Attributions 

## Attributions 

Photo attributions used in `mnt/server/sample-files`:

- **gt-einstein:**  Patrick Ward - used by permission 
- **gt-campanile:** [https://commons.wikimedia.org/wiki/File:Kessler_Campanile,_Georgia_Tech.jpg](https://commons.wikimedia.org/wiki/File:Kessler_Campanile,_Georgia_Tech.jpg)
- **gt-klaus:** [https://commons.wikimedia.org/wiki/File:Klaus_Building_Front.jpg](https://commons.wikimedia.org/wiki/File:Klaus_Building_Front.jpg)
