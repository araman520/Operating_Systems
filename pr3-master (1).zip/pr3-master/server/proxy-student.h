/*
 *  This file is for use by students to define anything they wish.  It is used by both proxy server implementation
 */
 #ifndef __SERVER_STUDENT_H__
 #define __SERVER_STUDENT_H__

 #include "steque.h"
 
 #endif // __SERVER_STUDENT_H__